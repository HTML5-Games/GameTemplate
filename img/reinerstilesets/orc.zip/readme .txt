Bitte beachten:

Da f�r die Umkippanimation auf einem 96 X 96 er Tile schlichtweg zu wenig Platz vorhanden war,habe ich selbige in einer Gr�sse von 128 X 128 gerendert.
Dies bedeutet, dass sich der Nullpunkt im Vergleich zum restlichen Sprite f�r die Umkippanimation bei -16 / -16 befindet ...
Deswegen befindet sich die Umkipp Animation auch in einem Extraordner.

Reiner

Attention :

Because there wasn�t enough space to display the full tipping over animation at an 96 X 96 Tile, i have rendered the tipping over animation in a size of 128 x 128.
This means that the zero point of this animation is -16 /-16 compared to the rest of the sprite ...
That�s why the tipping over animation is in an extrafolder.

Reiner